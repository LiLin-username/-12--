import UIKit

class MyView: UIView{
    override func draw(_ rect: CGRect) {
        let path = UIBezierPath(ovalIn: rect)
        UIColor.blue.setStroke()//蓝色边界
        path.stroke()
        
        UIColor.yellow.setFill()//黄色填充
        path.fill()
        
        path.move(to: CGPoint(x: rect.size.width/2, y: 0))
    }
}

//在ViewController中使用自定义的UIView创建一个椭圆
let view = UIView(frame: CGRect(x: 0, y: 0, width: 500, height: 400))//定义一个View
view.backgroundColor = UIColor.purple
let oval = MyView(frame: CGRect(x: 100, y: 100, width: 250, height: 200))//自制椭圆
oval.backgroundColor = UIColor.clear
view.addSubview(oval)
